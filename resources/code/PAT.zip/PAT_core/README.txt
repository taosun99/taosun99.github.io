As the code is not ready to publish, some names are not as same as in the paper. 
FYI, `GSA` is in `sat.group_attention.GroupAttention`, 
`GSS` is in `sat.aggregate.GumbelSubsetSelection`, 
and `ARPE` is in `point_cloud_modules.relative_position_encoding.RelativePositionEncodin`.

Feel free to ask any detailed question, on algorithms or implementation.