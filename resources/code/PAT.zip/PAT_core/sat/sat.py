import torch.nn as nn

from .group_attention import GABlock
from .multi_head_attention import MHABlock


class SATBlock(nn.Module):
    '''A wrapper for GABlock / MHABlock.'''

    def __init__(self, hidden_size=256, groups=8, L=1, use_gumbel_trick=False,
                 scale=True, norm=None, agg=None, attention='GA', activation_fn=nn.ELU):
        print("DeprecationWarning: The wrapper `SATBlock` @(%s) is deprecated..." % __file__)

        super().__init__()

        if attention == 'GA':
            Block = GABlock
        elif attention == 'MHA':
            Block = MHABlock
        else:
            raise ValueError

        transmits = []
        for _ in range(L):
            transmits.append(Block(hidden_size, groups, use_gumbel_trick, scale, norm, activation_fn))
        self.transmits = nn.ModuleList(transmits)

        if agg is None:
            self.agg_fn = lambda x, m: x
        else:
            self.agg_fn = GlobalPool(agg)

    def forward(self, x, mask, T=1):

        attns = []
        for transmit in self.transmits:
            for _ in range(T):  # there cloud be some work done here
                x, attn = transmit(x, mask)
                attns.append(attn)

        return self.agg_fn(x, mask), attns


class GlobalPool(nn.Module):
    def __init__(self, agg):
        super().__init__()
        assert agg in ["avg", 'max']
        self.agg = agg

    def forward(self, x, mask):
        if self.agg == 'max':
            if mask is None:
                return x.max(dim=1)[0]
            NINF = -9e15
            masked = x.masked_fill_((1 - mask).unsqueeze(-1), NINF)
            return masked.max(dim=1)[0]
        if self.agg == 'avg':
            if mask is None:
                return x.mean(dim=1)
            x_sum = (x * mask.float().unsqueeze(-1)).sum(1)
            x_count = mask.float().sum(-1, keepdim=True)
            return x_sum / x_count
