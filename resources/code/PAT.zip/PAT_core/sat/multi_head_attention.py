import torch
import torch.nn as nn
import torch.nn.functional as F

from ..normalizations import LayerNorm, GroupNorm
from .attention import DotProductAttention


# TODO: now this does only support basic SAT operations.


class MHABlock(nn.Module):

    def __init__(self, hidden_size, groups, use_gumbel_trick, scale, norm, activation_fn):
        super().__init__()
        self.attn_layer = MultiHeadAttention(hidden_size, groups=groups,
                                             use_gumbel_trick=use_gumbel_trick,
                                             scale=scale, activation_fn=activation_fn)
        self.dropout_p = 0.1

        if norm == "layer_norm":
            # print("use layer norm.")
            self.norm1 = LayerNorm(hidden_size)
            self.norm2 = LayerNorm(hidden_size)
        elif norm == "group_norm":
            # print("use layer norm.")
            self.norm1 = GroupNorm(groups, hidden_size)
            self.norm2 = GroupNorm(groups, hidden_size)
        elif norm is None:
            self.norm1 = lambda x: x
            self.norm2 = lambda x: x
        else:
            raise ValueError

        self.feedforward = nn.Sequential(nn.Linear(hidden_size, hidden_size), activation_fn(),
                                         nn.Linear(hidden_size, hidden_size))

    def forward(self, x, mask):
        residual, attns = self.attn_layer(x, mask)
        dropped = F.dropout(residual, p=self.dropout_p, training=self.training)
        x = self.norm1(dropped + x)

        residual = self.feedforward(x)
        dropped = F.dropout(residual, p=self.dropout_p, training=self.training)
        x = self.norm2(dropped + x)
        return x, attns


class MultiHeadAttention(nn.Module):
    def __init__(self, d, groups, use_gumbel_trick, scale, activation_fn):
        '''

        :param d: d_model
        :param group: n_head
        :param d_k:
        :param d_v:
        '''
        super().__init__()

        if groups > 1:
            assert d % groups == 0

        self.project = nn.Linear(d, d)
        self.project_back = nn.Linear(d, d)
        self.attention = DotProductAttention(use_gumbel_trick, scale)
        self.v_activation = activation_fn()
        self.groups = groups

    def forward(self, x, mask):

        feat = self.project(x)
        feat_groups = torch.cat(feat.chunk(self.groups, dim=-1), dim=0)  # Bxgroup x length x d_v

        if mask is not None:
            mask = mask.repeat(self.groups, 1)

        score_groups, attn_groups = self.attention(feat_groups, feat_groups, self.v_activation(feat_groups), mask)
        # Bxgroup x length x d_v, Bxgroup x length x length

        score = torch.cat(score_groups.chunk(self.groups, dim=0), dim=-1)  # B x length x d
        attns = attn_groups.chunk(self.groups, dim=0)  # [B x length x length] x group

        score = self.project_back(score)

        return score, attns
