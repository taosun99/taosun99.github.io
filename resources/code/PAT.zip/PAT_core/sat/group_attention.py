import torch
from torch import nn as nn
from torch.utils.checkpoint import checkpoint

from ..normalizations import LayerNorm, GroupNorm
from .attention import DotProductAttention


class GABlock(nn.Module):

    def __init__(self, out_features, groups, use_gumbel_trick, scale, norm, activation_fn,
                 topk, dilation, thresh, memory_efficient, in_features=None):
        super().__init__()

        self.attn_layer = GroupAttention(out_features, groups, use_gumbel_trick, scale, activation_fn,
                                         topk, dilation, thresh, memory_efficient, in_features=in_features)

        if norm == "layer_norm":
            # print("use layer norm.")
            self.norm = LayerNorm(out_features)
        elif norm == 'group_norm':
            self.norm = GroupNorm(groups, out_features)
        elif norm is None:
            self.norm = lambda x: x
        else:
            raise ValueError

        self.channel_shuffle = ChannelShuffle(groups)

    def forward(self, x, mask):
        residual, attns = self.attn_layer(x, mask)
        # residual, attns = checkpoint(self.attn_layer, x, mask)

        # channel shuffle here? (more shuffle effects)
        residual = self.channel_shuffle(residual)

        x = self.norm(residual + x)

        # or channel shuffle here? (cleaner)
        # x = self.channel_shuffle(x)
        return x, attns


class ChannelShuffle(nn.Module):
    ''' channel_last implementation. '''

    def __init__(self, groups):
        super().__init__()
        self.groups = groups

    def forward(self, x):
        *size_except_channel, channels = x.size()
        assert channels % self.groups == 0
        channels_per_group = channels // self.groups
        x = x.view(*(size_except_channel + [channels_per_group, self.groups]))
        x = x.transpose(-1, -2).contiguous()
        x = x.view(*(size_except_channel + [-1]))
        return x


class GroupAttention(nn.Module):
    '''　this looks like a `group attention` (just like `group conv` as to `conv`).
    for `groups=1`, paramters are the same, but the `groups>1` will reduce the computation cost.'''

    def __init__(self, out_features, groups, use_gumbel_trick, scale, activation_fn, topk, dilation, thresh,
                 memory_efficient, in_features=None):
        '''

        :param d: d_model
        :param group: n_head
        :param d_k:
        :param d_v:
        '''
        super().__init__()

        if in_features is None:
            in_features = out_features

        self.project = GroupPositionWise(in_features, out_features, groups)
        self.attention = DotProductAttention(use_gumbel_trick, scale, topk, dilation, thresh)
        self.v_activation = activation_fn()
        self.groups = groups
        self.memory_efficient = memory_efficient

    def forward(self, x, mask):
        if torch.is_grad_enabled() and self.memory_efficient:
            return self.forward_memory_efficient(x, mask)
        return self.forward_fast(x, mask)

    # def forward_v1(self, x, mask):
    #
    #     feat = self.project(x)
    #     feat_groups = torch.cat(feat.chunk(self.groups, dim=-1), dim=0)  # Bxgroup x length x d_v
    #
    #     if mask is not None:
    #         mask = mask.repeat(self.groups, *(1,) * (mask.dim() - 1))
    #
    #     v_groups = self.v_activation(feat_groups)
    #
    #     score_groups, attn_groups = checkpoint(self.attention, feat_groups, feat_groups, v_groups, mask)
    #     # score_groups, attn_groups = self.attention(feat_groups, feat_groups, v_groups, mask)
    #     # Bxgroup x length x d_v, Bxgroup x length x length
    #
    #     score = torch.cat(score_groups.chunk(self.groups, dim=0), dim=-1)  # B x length x d
    #     attns = attn_groups.chunk(self.groups, dim=0)  # [B x length x length] x group
    #
    #     return score, attns

    def forward_memory_efficient(self, x, mask):
        feat = self.project(x)

        score_groups = []
        attns = []
        for feat_group in feat.chunk(self.groups, dim=-1):
            score_group, attn_group = checkpoint(self.attention,
                                                 feat_group, feat_group, self.v_activation(feat_group), mask)
            score_groups.append(score_group)
            attns.append(attn_group)
        # score_groups, attn_groups = self.attention(feat_groups, feat_groups, v_groups, mask)
        # Bxgroup x length x d_v, Bxgroup x length x length

        score = torch.cat(score_groups, dim=-1)  # B x length x d

        return score, attns

    def forward_fast(self, x, mask):
        feat = self.project(x)

        score_groups = []
        attns = []
        for feat_group in feat.chunk(self.groups, dim=-1):
            score_group, attn_group = self.attention(feat_group, feat_group, self.v_activation(feat_group), mask)
            score_groups.append(score_group)
            attns.append(attn_group)
        # score_groups, attn_groups = self.attention(feat_groups, feat_groups, v_groups, mask)
        # Bxgroup x length x d_v, Bxgroup x length x length

        score = torch.cat(score_groups, dim=-1)  # B x length x d

        return score, attns


class GroupPositionWise(nn.Module):
    '''A little speed up and simplification.'''

    def __init__(self, in_features, out_features, groups):
        super().__init__()

        assert in_features % groups == 0
        assert out_features % groups == 0
        group_linear = []
        for _ in range(groups):
            group_linear.append(nn.Linear(in_features // groups, out_features // groups))
        self.group_linear = nn.ModuleList(group_linear)
        self.groups = groups

    def forward(self, x):
        x_groups = x.chunk(self.groups, dim=-1)
        ret = []
        for m, f in zip(self.group_linear, x_groups):
            ret.append(m(f))
        return torch.cat(ret, dim=-1)


class ResidualGroupConnected(nn.Module):
    def __init__(self, structures, groups, activation_fn):
        super().__init__()
        # self.in_features = structures[0]
        # self.out_features = structures[-1]
        layers = len(structures) - 1
        assert layers >= 1
        blocks = []

        for i in range(layers):
            blocks.append(self.get_single_block(structures[i], structures[i + 1], groups, activation_fn))

        if structures[0] != structures[-1]:
            self.dim_change = blocks[0]  # make the first not in residual connections
            self.blocks = nn.Sequential(*blocks[1:])
        else:
            self.dim_change = lambda x: x  # keep the residual connections from input to output
            print("Group Connected: all in residual.")
            self.blocks = nn.Sequential(*blocks)

    @staticmethod
    def get_single_block(in_features, out_features, groups, activation_fn):
        return nn.Sequential(GroupPositionWise(in_features, out_features, groups),
                             GroupNorm(groups, out_features), activation_fn(),
                             ChannelShuffle(groups))

    def forward(self, x):
        x = self.dim_change(x)
        residual = self.blocks(x)
        return residual + x
