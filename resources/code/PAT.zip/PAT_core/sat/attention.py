import torch
from torch import nn as nn
import torch.nn.functional as F


class DotProductAttention(nn.Module):
    # TODO: fix `thresh(!)`　(core dumped)
    def __init__(self, use_gumbel_trick, scale=True, topk=None, dilation=None, thresh=None):
        super().__init__()
        self.scale = scale
        if use_gumbel_trick:
            self.noiser = GumbelNoiser()
        else:
            # self.noiser = nn.Dropout(p=0.1)
            self.noiser = lambda x: x
        if topk is not None:
            assert thresh is None
            assert dilation is not None
            self.softmax = TopkSoftmax(k=topk, dilation=dilation, dim=-1)
        elif thresh is not None:
            assert topk is None
            self.softmax = ThreshSoftmax(thresh=thresh, dim=-1)
        else:
            self.softmax = nn.Softmax(dim=-1)

    def forward(self, q, k, v, mask):
        '''
        :param q: B x length1 x size1
        :param k: B x length2 x size1
        :param v: B x length2 x size2
        :param mask: B x length1(=length2)

        length1=length2 or size1=size2 is possible

        :return: B x length1 x size2, B x length1 x length2
        '''

        B, length1, size1 = q.size()
        _B, length2, size1_ = k.size()
        __B, _length2, size2 = v.size()
        assert B == _B == __B, 'batch matching'
        assert size1 == size1_, "size1 matching"
        assert length2 == _length2, "length2 matching"

        temperature = (size1 ** .5) if self.scale else 1.
        attn_logits = q.bmm(k.transpose(1, 2))
        logits = self.noiser(attn_logits / temperature)
        if mask is not None:
            assert length1 == length2, "this mask implementation only consider same length mask."
            logits = masked_logits(logits, mask)
        attn = self.softmax(logits)
        score = attn.bmm(v)
        return score, attn


class GumbelNoiser(nn.Module):
    '''
    Add Gumbel Noise (to pre-softmax attention) when training.
    '''

    def __init__(self, smooth=1e-9, force=False):
        super().__init__()
        self.smooth = smooth
        self.force = force

    def forward(self, x):
        if self.training or self.force:
            noise = torch.rand_like(x)
            noise.add_(self.smooth).log_().neg_()
            noise.add_(self.smooth).log_().neg_()
            return x + noise
        return x


def masked_logits(logits, masks, auto_reshape=True):
    '''

    :param logits: BxLxL
    :param masks: BxLxL or BxL
    :param auto_reshape: reshape BxL input into Bx1xL (like BxLxL)
    :return:
    '''
    if auto_reshape and masks.shape != logits.shape:
        masks = masks.unsqueeze(1)

    NINF = -9e15
    pad_values = torch.ones_like(logits).fill_(NINF)
    masked_logits = torch.where(masks, logits, pad_values)  # the pad col will be 0
    # the following line just indicates the padded should not have normal attn
    # masked_logits = torch.where(masks.unsqueeze(2), masked_logits, pad_values)  # the pad row will be 1/n
    return masked_logits


class TopkSoftmax(nn.Module):
    def __init__(self, k, dilation=1, dim=-1):
        super().__init__()
        self._k = k
        self._dilation = dilation
        self.dim = dim

    @property
    def top_k(self):
        return int(self._k * self.dilation)

    @property
    def dilation(self):
        return self._dilation

    @dilation.setter
    def dilation(self, value):
        if self._dilation != value:
            print("Setting the TopkSoftmax dilation: %s=>%s" % (self._dilation, value))
            self._dilation = value

    def forward(self, x):
        NINF = -9e15
        min_k = min(self.top_k, x.size(self.dim))
        _, indices = torch.topk(x, k=min_k, dim=self.dim)
        mask = torch.ones_like(x).scatter_(self.dim, indices, value=0).byte()
        pre_softmax = x.masked_fill_(mask, NINF)  # TODO: inplace or not?
        return F.softmax(pre_softmax, dim=self.dim)


class ThreshSoftmax(nn.Module):
    def __init__(self, thresh=0., dim=-1):
        super().__init__()
        self.dim = dim
        self.thresh = nn.Parameter(torch.tensor(thresh))

    def forward(self, x):
        NINF = -9e15
        cutted = x - self.thresh
        # print("Current threshold: %.4f" % self.thresh.item())
        return cutted.masked_fill(cutted <= 0, NINF).softmax(dim=self.dim)
