import torch.nn as nn
import torch.nn.functional as F

from .group_attention import GroupAttention


class GlobalPool(nn.Module):
    def __init__(self, agg):
        super().__init__()
        assert agg in ["avg", 'max']
        self.agg = agg

    def forward(self, x, mask):
        if self.agg == 'max':
            if mask is None:
                return x.max(dim=1)[0]
            NINF = -9e15
            masked = x.masked_fill((1 - mask).unsqueeze(-1), NINF)
            return masked.max(dim=1)[0]
        if self.agg == 'avg':
            if mask is None:
                return x.mean(dim=1)
            x_sum = (x * mask.float().unsqueeze(-1)).sum(1)
            x_count = mask.float().sum(-1, keepdim=True)
            return x_sum / x_count


class GumbelSubsetSelection_v1(nn.Module):

    def __init__(self, in_features, select_N, activation_fn):
        super().__init__()
        # self.selector = nn.Sequential(nn.Linear(in_features, in_features // 2), activation_fn(),
        self.selector = nn.Sequential(nn.Linear(in_features, in_features // 2), nn.Tanh(),
                                      nn.Linear(in_features // 2, select_N))

    def forward(self, x, mask=None, tau=1, hard=False):
        select_weights = self.selector(x)
        if mask is not None:
            NINF = -9e15
            select_weights = select_weights.masked_fill((1 - mask).unsqueeze(-1), NINF)
        B, N, select_N = select_weights.shape
        attn = F.gumbel_softmax(select_weights.transpose(1, 2).contiguous().view(-1, N), tau=tau, hard=hard)
        attn = attn.view(B, select_N, N)
        selected = attn.matmul(x)
        return selected, attn


class GumbelSubsetSelection_v2(nn.Module):

    def __init__(self, in_features, select_N, activation_fn):
        super().__init__()
        # self.selector = nn.Sequential(nn.Linear(in_features, in_features // 2), activation_fn(),
        self.aggregator = GroupAttention(in_features, groups=8,
                                         use_gumbel_trick=False, scale=True, activation_fn=activation_fn,
                                         topk=None, dilation=None, thresh=None,
                                         memory_efficient=False, out_features=in_features // 2)
        self.selector = nn.Linear(in_features // 2, select_N)

    def forward(self, x, mask=None, tau=1, hard=False):
        score, _ = self.aggregator(x, mask)
        select_weights = self.selector(score)
        if mask is not None:
            NINF = -9e15
            select_weights = select_weights.masked_fill((1 - mask).unsqueeze(-1), NINF)
        B, N, select_N = select_weights.shape
        attn = F.gumbel_softmax(select_weights.transpose(1, 2).contiguous().view(-1, N), tau=tau, hard=hard)
        attn = attn.view(B, select_N, N)
        selected = attn.matmul(x)
        return selected, attn


class GumbelSubsetSelection_v3(nn.Module):

    def __init__(self, in_features, select_N, activation_fn):
        super().__init__()
        self.selector = nn.Linear(in_features, select_N)

    def forward(self, x, mask=None, tau=1, hard=False):
        select_weights = self.selector(x)
        if mask is not None:
            NINF = -9e15
            select_weights = select_weights.masked_fill((1 - mask).unsqueeze(-1), NINF)
        B, N, select_N = select_weights.shape
        attn = F.gumbel_softmax(select_weights.transpose(1, 2).contiguous().view(-1, N), tau=tau, hard=hard)
        attn = attn.view(B, select_N, N)
        selected = attn.matmul(x)
        return selected, attn


GumbelSubsetSelection = GumbelSubsetSelection_v3
