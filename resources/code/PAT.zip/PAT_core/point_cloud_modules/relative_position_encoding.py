import torch
import torch.nn as nn

from .knn_graph import batch_compute_distance
from ..normalizations import GroupNorm
from ..sat.attention import masked_logits


class RelativePositionEncoding(nn.Module):
    def __init__(self, input_size, output_size, k_neighbors, activation_fn, dilation, use_absolute_pos,
                 hidden_size=128):
        super().__init__()
        if use_absolute_pos:
            input_size = input_size * 2
        self.use_absolute_pos = use_absolute_pos
        self.shared_mlp = nn.Sequential(nn.Linear(input_size, 64), GroupNorm(8, 64), activation_fn(),
                                        nn.Linear(64, hidden_size), GroupNorm(8, hidden_size), activation_fn(),
                                        nn.Linear(hidden_size, hidden_size), GroupNorm(8, hidden_size), activation_fn())
        self.fc = nn.Sequential(nn.Linear(hidden_size, hidden_size), GroupNorm(8, hidden_size), activation_fn(),
                                nn.Linear(hidden_size, output_size), GroupNorm(8, output_size), activation_fn())
        self.k_neighbors = k_neighbors
        self._dilation = dilation

    def forward(self, x, distance_matrix, mask=None):
        '''We do not need to care the mask!
        The masked points should be processed in the following module.

        :param x: B x N x input_size
        :param distance_matrix: B x N x N
        :return: B x N x output_size
        '''
        if distance_matrix is None:
            distance_matrix = batch_compute_distance(x)
            if mask is not None:
                distance_matrix = masked_logits(distance_matrix, mask)  # TODO: put it a better place

        N = x.size(1)
        assert N > self.k_neighbors, "`k_neighbors` should be at most N-1."
        relative_pos = compute_topk_relative_pos(x, distance_matrix, self.k_neighbors, self.dilation,
                                                 self.use_absolute_pos)  # B x N x k x C(2C)
        features = self.shared_mlp(relative_pos)
        pooled = features.max(dim=2)[0]
        feature = self.fc(pooled)
        return feature

    @property
    def dilation(self):
        return self._dilation

    @dilation.setter
    def dilation(self, value):
        if self._dilation != value:
            print("Setting the RPE dilation: %s=>%s" % (self._dilation, value))
            self._dilation = value


def compute_topk_relative_pos(x, distance_matrix, k, dilation, use_absolute_pos):
    '''

    :param x: BxNxC
    :param distance_matrix: BxNxN
    :param k: int
    :param dilation: int, default 1
    :return: BxNxkxC
    '''

    dilated_k = int(dilation * k)

    _, index = torch.topk(-distance_matrix, k=dilated_k + 1, dim=-1)  # do not use the top1, i.e., itself
    top_index = index[:, :, 1:]
    if dilation > 1:
        top_index = top_index.index_select(dim=-1, index=torch.randperm(dilated_k)[:k].type_as(top_index))
    ret = []
    for topi_index in top_index.split(dim=-1, split_size=1):
        relative_pos_i = torch.gather(x, dim=1, index=topi_index.repeat(1, 1, 3)) - x
        if use_absolute_pos:
            relative_pos_i = torch.cat([relative_pos_i, x], dim=-1)
        ret.append(relative_pos_i)
    relative_pos = torch.stack(ret, dim=2)
    return relative_pos
