import torch
import torch.nn as nn
import torch.nn.functional as F
from ..sat.aggregate import GlobalPool
from ..normalizations import GroupNorm


class TNet(nn.Module):

    def __init__(self, input_size, activation_fn):
        super().__init__()
        self.shared_mlp = nn.Sequential(nn.Linear(input_size, 64), GroupNorm(8, 64), activation_fn(),
                                        nn.Linear(64, 128), GroupNorm(8, 128), activation_fn(),
                                        nn.Linear(128, 1024), GroupNorm(8, 1024), activation_fn())
        self.fc = nn.Sequential(nn.Linear(1024, 512), GroupNorm(8, 512), activation_fn(),
                                nn.Linear(512, 256), GroupNorm(8, 256), activation_fn())
        self.agg = GlobalPool('max')
        self.W = nn.Parameter(torch.zeros(input_size * input_size, 256).normal_(std=0.001))
        self.b = nn.Parameter(torch.zeros(input_size * input_size))
        self.input_size = input_size

    def forward(self, x, mask=None):
        features = self.shared_mlp(x)
        pooled = self.agg(features, mask)
        global_feature = self.fc(pooled)
        zero_transform = F.linear(global_feature, self.W, self.b).view(-1, self.input_size, self.input_size)
        transform = zero_transform + torch.eye(self.input_size).type_as(zero_transform).unsqueeze_(0)
        transformed = x.matmul(transform)
        return transformed
