def batch_compute_distance_large_memory(x, y=None):
    '''

    :param x: NxC
    :param y: NxC
    :return: NxN
    '''
    if y is None:
        y = x
    diff = x.unsqueeze(1) - y.unsqueeze(2)
    dist = (diff * diff).sum(-1).sqrt()
    return dist


def batch_compute_distance_memory_efficient(X, Z=None):
    '''code from https://github.com/erikwijmans/Pointnet2_PyTorch/blob/master/utils/linalg_utils.py
    while it is still very slow and consumes large memory.
    '''
    if Z is None:
        Z = X
        G = X @ Z.transpose(-2, -1)
        S = (X * X).sum(-1, keepdim=True)
        R = S.transpose(-2, -1)
    else:
        G = X @ Z.transpose(-2, -1)
        S = (X * X).sum(-1, keepdim=True)
        R = (Z * Z).sum(-1, keepdim=True).transpose(-2, -1)
    ret = (R + S - 2 * G).abs().sqrt()
    del G, S, R
    return ret

# TODO: a pure cuda version should work better
batch_compute_distance = batch_compute_distance_memory_efficient